// Função para subtrair dois números

export function subtrair(a, b){
    return a - b;
}