// Função para dividir dois números

export function dividir(a,b){
    return a / b;
}