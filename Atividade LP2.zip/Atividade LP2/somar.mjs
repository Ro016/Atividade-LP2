// Função para somar dois números

export function somar(a, b){
    return a + b;
}