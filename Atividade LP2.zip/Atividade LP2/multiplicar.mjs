// Função para multiplicar dois números

export function multiplicar(a,b){
    return a * b;
}