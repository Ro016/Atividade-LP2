// Função para potência

export function potencia(a,b){
    return a ** b;
}